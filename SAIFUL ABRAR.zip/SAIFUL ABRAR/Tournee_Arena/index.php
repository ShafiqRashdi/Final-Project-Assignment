<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");  //include connection file
error_reporting(0);  // using to hide undefine undex errors
session_start(); //start temp session until logout/browser closed

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Welcome To Tournee Arena</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet"> 
    <link href="footer.css" rel="stylesheet"> 
</head>

<body class="home">
    
        <!--header starts-->
        <header id="header" class="header-scroll top-header headrom headerBg">
            <!-- .navbar -->
            <nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.php"> MyGamez<span>..</span> </a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                        
                            <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
                            <li class="nav-item"> <a class="nav-link active" href="admin/dashboard.php">Admin <span class="sr-only"></span></a> </li>
                            <li class="nav-item"> <a class="nav-link active" href="faq.php">FAQ <span class="sr-only"></span></a> </li>
    
                       
                        <li class="nav-item"> <a class="nav-link active" href="ml_diamonds.php">Gamez <span class="sr-only"></span></a> </li>
                       
                        
                            
                            
                           
							<?php
						if(empty($_SESSION["user_id"])) // if user is not login
							{
								echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
							  <li class="nav-item"><a href="registration.php" class="nav-link active bgGreen">Signup</a> </li>';
							}
						else
							{
									//if user is login
									
									
									echo  '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
							}

						?>
							 
                        </ul>
						 
                    </div>
                </div>
            </nav>
            <!-- /.navbar -->
        </header>
        <!-- banner part starts -->
        <section class="hero bg-image" data-image-src="images/ml3.jpg">
            <div class="hero-inner">
                <div class="container text-center hero-text font-white">
                    <h1>Welcome To Tournee Arena</h1>
                    <h5 class="font-white space-xs">The fastest & easiest way to buy game credits</h5>
                    <div class="banner-form">
                        <form class="form-inline">
                            <div class="form-group">
                                <label class="sr-only" for="exampleInputAmount">I would like to eat....</label>
                                <div class="form-group">
                                     </div>
                            </div>
                            
                        </form>
                    </div>
                  
                    
                </div>
            </div>
            <!--end:Hero inner -->
        </section>
        <!-- banner part ends -->
      
        

 <section class="section aboutSection" id ="about">
        <div class="sectionContent container">
           <div class="sectionIntro">
               <div class="headerInfo">
                   <h2 class="title">About MyGamez</h2>
                   <p class="subTitle">Codashop is the safe and easy way to buy official game and app credits. We are trusted by millions of gamers and app users in over 50 countries including Malaysia. Top up now.

Codashop Malaysia offers Mobile Legends Diamond, Weekly Diamond Pass, and Twilight Pass which unlocks access to premium content in the game, bringing your gameplay to the next level! </p>
               </div>
           </div>
           <div class="sectionData">
           <div class="leftImg">
              <img src="./images/ml5.jpg" alt="Simcard Image">
              </div>
              <div class="rightImgs">
                  <div class="rightImg">
                      <img src="./images/ml6.jpeg" alt="Food Image">
                  </div>
                  <div class="rightImg">
                      <img src="./images/ml7.png" alt="Food Image">
                  </div>
                  <div class="rightImg">
                      <img src="./images/ml8.jpg" alt="Food Image">
                  </div>
                  <div class="rightImg">
                      <img src="./images/ml9.jpg" alt="Food Image">
                  </div>
                  
              </div>
           </div>
        </div>
    </section>

   



  <!-- FOOTER SECTION ----------------------- -->
  <section class="footerSection">
    <div class="contentContainer container">
        <div class="footerIntro">
            <div class="footerLogoDiv">
                <span class="hotelName">
                    Why Choose Mygamez for Mobile Legends top up?<span>..</span>
                </span>
            </div>
            <p>Quick and Easy

It only takes a few seconds to top up MLBB Diamond, WDP, and Twilight Pass on Codashop..</p>

            <div class="footContactDetails">
                <div class="info">
                    <div class="iconDiv"><i class='bx bx-mail-send' ></i></div>
                    <span>MyGamez@gmail.com</span>
                </div>

                <div class="info">
                    <div class="iconDiv"><i class='bx bxs-phone-outgoing'></i></div>
                    <span>+60 182936271</span>
                </div>

                <div class="info">
                    <div class="iconDiv"><i class='bx bx-current-location' ></i></div>
                    <span>Cheras Kuala Lumpur</span>
                </div>
            </div>
        </div>

        

        
</section>
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
    <script src="js/isratech.js"></script>

</body>

</html>