<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if(empty($_SESSION["user_id"])) {
    header('location:login.php');
} else {
    // Process form submission
    if(isset($_POST['submit'])) {
        $game_id = $_POST['game_id'];
        $server_id = $_POST['server_id'];
        $diamond_amount = $_POST['diamond_amount'];
        $price = $_POST['price'];
        $user_id = $_SESSION["user_id"];
        
        // Insert into database
        $sql = "INSERT INTO ml_diamonds(u_id, game_id, server_id, diamond_amount, price, status) 
                VALUES('$user_id', '$game_id', '$server_id', '$diamond_amount', '$price', 'pending')";
        
        mysqli_query($db, $sql);
        
        $success = "Your Mobile Legends diamonds order has been placed successfully!";
    }
}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>ML Diamonds - Tournee Arena</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark bg-dark" style="background-color: rgb(68, 95, 85) !important;">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php"> Tournee Arena<span>..</span> </a>
                <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="ml_diamonds.php">ML Diamonds <span class="sr-only"></span></a> </li>
                        
                        <?php
                        if(empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
                            <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a> </li>';
                        } else {
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    
    <div class="page-wrapper">
        <div class="top-links">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item"><span>1</span><a href="index.php">Home</a></li>
                    <li class="col-xs-12 col-sm-4 link-item active"><span>2</span><a href="ml_diamonds.php">ML Diamonds</a></li>
                </ul>
            </div>
        </div>
        
        <div class="container">
            <div class="widget clearfix">
                <div class="widget-heading">
                    <h3 class="widget-title text-dark">
                        Mobile Legends Diamonds Topup
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <?php
                    if(isset($success)) {
                        echo '<div class="alert alert-success">
                            <strong>Success!</strong> '.$success.'
                        </div>';
                    }
                    ?>
                    
                    <form method="post" action="">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Game ID</label>
                                    <input type="text" name="game_id" class="form-control" placeholder="Enter your Mobile Legends ID" required>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Server ID</label>
                                    <input type="text" name="server_id" class="form-control" placeholder="Enter your Server ID" required>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Diamond Amount</label>
                                    <select name="diamond_amount" class="form-control" required>
                                        <option value="">Select Diamond Amount</option>
                                        <option value="50">50 Diamonds</option>
                                        <option value="100">100 Diamonds</option>
                                        <option value="250">250 Diamonds</option>
                                        <option value="500">500 Diamonds</option>
                                        <option value="1000">1000 Diamonds</option>
                                        <option value="2000">2000 Diamonds</option>
                                        <option value="5000">5000 Diamonds</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Price (RM)</label>
                                    <select name="price" class="form-control" required>
                                        <option value="">Select Price</option>
                                        <option value="10">RM 10 (50 Diamonds)</option>
                                        <option value="20">RM 20 (100 Diamonds)</option>
                                        <option value="50">RM 50 (250 Diamonds)</option>
                                        <option value="100">RM 100 (500 Diamonds)</option>
                                        <option value="200">RM 200 (1000 Diamonds)</option>
                                        <option value="400">RM 400 (2000 Diamonds)</option>
                                        <option value="1000">RM 1000 (5000 Diamonds)</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <p class="text-info">
                                    <strong>Note:</strong> Your diamonds will be credited to your Mobile Legends account within 24 hours after payment confirmation.
                                </p>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <input type="submit" name="submit" value="Order Diamonds" class="btn btn-primary">
                            </div>
                        </div>
                    </form>
                </div>
                
                <div class="widget-heading mt-4">
                    <h3 class="widget-title text-dark">
                        My Diamond Orders
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Game ID</th>
                                    <th>Server ID</th>
                                    <th>Diamond Amount</th>
                                    <th>Price (RM)</th>
                                    <th>Status</th>
                                    <th>Order Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if(!empty($_SESSION["user_id"])) {
                                    $user_id = $_SESSION["user_id"];
                                    $query = mysqli_query($db, "SELECT * FROM ml_diamonds WHERE u_id='$user_id' ORDER BY order_date DESC");
                                    
                                    if(mysqli_num_rows($query) > 0) {
                                        while($row = mysqli_fetch_array($query)) {
                                            echo '<tr>
                                                <td>'.$row['game_id'].'</td>
                                                <td>'.$row['server_id'].'</td>
                                                <td>'.$row['diamond_amount'].' Diamonds</td>
                                                <td>RM '.$row['price'].'</td>
                                                <td>'.ucfirst($row['status']).'</td>
                                                <td>'.date('d-m-Y h:i A', strtotime($row['order_date'])).'</td>
                                            </tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="6" class="text-center">No diamond orders found</td></tr>';
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include "footer.php"; ?>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>
</html>