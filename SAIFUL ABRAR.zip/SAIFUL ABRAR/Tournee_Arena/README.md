READ ME!!

.............About this project? 
If you are here first of all thanks for supporting IsraTech, please subscribe to the channel for more content like this.

PLEASE NOTE:
Please note that the admin folder for is not included in the zip you donwloaded and here is it's link
Admin Folder Link: https://drive.google.com/drive/folders/1xsv-sWFjSp0bRexJH1oAat4tNaUyD9uH?usp=sharing

Download the admin folder and paste as it is in the Foodie Folder.
 
Enjoy the project and let me know in the comments if there's any questions regarding this project.


........... Installation or Demo

Watch this video: https://youtu.be/n1A-NK0gB5o

.............Admin Dashboard

To access admin portal type this in your URL BAR - localhost/youdirectory/admin

............ Username: 
             isratech  
             Password: 
             isratech.1

............ Technologies Used

1. HTML
2. CSS
3. SASS
4. JavaScript
6. PHP
7. jQeury
8. Ajax
9. Bootstrap

............System Requirements

Software : XAMPP / Wamp / Mamp/ Lamp \(anyone\).



