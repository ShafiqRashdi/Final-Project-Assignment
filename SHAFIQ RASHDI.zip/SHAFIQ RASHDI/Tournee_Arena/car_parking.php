<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");  //include connection file
error_reporting(0);  // using to hide undefine undex errors
session_start(); //start temp session until logout/browser closed

// Cancel booking (cancel-only) handler
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_parking_id'])) {
    $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
    $parking_id = intval($_POST['cancel_parking_id']);
    if($user_id > 0 && $parking_id > 0) {
        $stmt = mysqli_prepare($db, "UPDATE car_parking SET status='cancelled', exit_time=NOW() WHERE parking_id=? AND u_id=? AND status='active'");
        if($stmt) {
            mysqli_stmt_bind_param($stmt, "ii", $parking_id, $user_id);
            mysqli_stmt_execute($stmt);
            if(mysqli_stmt_affected_rows($stmt) > 0) {
                $success = "Your booking has been cancelled.";
            } else {
                $error = "Unable to cancel. It may already be cancelled or completed.";
            }
            mysqli_stmt_close($stmt);
        } else {
            $error = "Cancellation failed due to a server error.";
        }
    } else {
        $error = "Invalid request.";
    }
}

// Booking handler
if(isset($_POST['submit'])) {
    if(empty($_SESSION['user_id'])) {
        $error = "You must be logged in to book a parking spot. <a href='login.php'>Click here to login</a>";
    } else {
        if(empty($_POST['vehicle_number']) || empty($_POST['vehicle_type']) || empty($_POST['parking_slot']) || empty($_POST['price'])) {
            $error = "All booking fields are required.";
        } else {
            $user_id = $_SESSION['user_id'];

            // Check if user already has an active booking
            $check_active_booking = mysqli_query($db, "SELECT * FROM car_parking WHERE u_id = '$user_id' AND status = 'active'");
            if(mysqli_num_rows($check_active_booking) > 0) {
                $error = "You already have an active booking. You can only have one active booking at a time.";
            } else {
                // Check for overlapping bookings for the same slot
                $parking_slot = mysqli_real_escape_string($db, $_POST['parking_slot']);
                $check_slot_query = mysqli_query($db, "SELECT * FROM car_parking WHERE parking_slot = '$parking_slot' AND status = 'active'");
                if(mysqli_num_rows($check_slot_query) > 0){
                    $error = "This parking slot is already booked. Please choose another one.";
                } else {
                    $vehicle_number = mysqli_real_escape_string($db, $_POST['vehicle_number']);
                    $vehicle_type = mysqli_real_escape_string($db, $_POST['vehicle_type']);
                    $price = mysqli_real_escape_string($db, $_POST['price']);

                    $sql = "INSERT INTO car_parking (u_id, vehicle_number, vehicle_type, parking_slot, price, status, entry_time) VALUES ('$user_id', '$vehicle_number', '$vehicle_type', '$parking_slot', '$price', 'active', NOW())";

                    if(mysqli_query($db, $sql)) {
                        $success = "Your parking has been booked successfully.";
                    } else {
                        $error = "Error booking parking: " . mysqli_error($db);
                    }
                }
            }
        }
    }
}

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Welcome To 123Parking</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet"> 
    <link href="footer.css" rel="stylesheet">
    
</head>

<body class="home" style="background: url('images/img/background4.jpg') no-repeat center center fixed; background-size: cover;">
    
        <!--header starts-->
        <header id="header" class="header-scroll top-header headrom headerBg">
            <!-- .navbar -->
            <nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.php"> 123Parking<span>..</span> </a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                        
                            <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
    
                        <li class="nav-item"> <a class="nav-link active" href="car_parking.php">Car Parking <span class="sr-only"></span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="about.php">About Us <span class="sr-only"></span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="faq.php">FAQ <span class="sr-only"></span></a> </li>

                            
                            
                           
							<?php
						if(empty($_SESSION["user_id"])) // if user is not login
							{
								echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
							  <li class="nav-item"><a href="registration.php" class="nav-link active bgGreen">Signup</a> </li>';
							}
						else
							{
									//if user is login
									
									echo  '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Booking</a> </li>';
									echo  '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
							}

						?>

                        <li class="nav-item"> <a class="nav-link active" href="/Tournee_Arena/Admin/dashboard.php">Admin <span class="sr-only"></span></a> </li>
							 
                        </ul>
						 
                    </div>
                </div>
            </nav>
            <!-- /.navbar -->
        </header>
    <div class="page-wrapper">
        <div class="top-links">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item"><span>1</span><a href="index.php">Home</a></li>
                    <li class="col-xs-12 col-sm-4 link-item active"><span>2</span><a href="car_parking.php">Car Parking</a></li>
                </ul>
            </div>
        </div>
        
        <div class="container">
            <div class="widget clearfix">
                <div class="widget-heading">
                    <h3 class="widget-title text-dark">
                        Car Parking Booking
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <?php
                    if(isset($success)) {
                        echo '<div class="alert alert-success">
                            <strong>Success!</strong> '.$success.'
                        </div>';
                    }
                    if(isset($error)) {
                        echo '<div class="alert alert-danger">
                            <strong>Error!</strong> '.$error.'
                        </div>';
                    }
                    ?>
                    
                    <form method="post" action="">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Vehicle Number</label>
                                    <input type="text" name="vehicle_number" class="form-control" placeholder="Enter Vehicle Number" required>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Vehicle Type</label>
                                    <select name="vehicle_type" class="form-control" required>
                                        <option value="">Select Vehicle Type</option>
                                        <option value="Car">Car</option>
                                        <option value="Motorcycle">Motorcycle</option>
                                        <option value="SUV">SUV</option>
                                        <option value="Van">Van</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Parking Slot</label>
                                    <select name="parking_slot" class="form-control" required>
                                        <option value="">Select Parking Slot</option>
                                        <option value="A1">A1</option>
                                        <option value="A2">A2</option>
                                        <option value="A3">A3</option>
                                        <option value="B1">B1</option>
                                        <option value="B2">B2</option>
                                        <option value="B3">B3</option>
                                        <option value="C1">C1</option>
                                        <option value="C2">C2</option>
                                        <option value="C3">C3</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Price (RM)</label>
                                    <select name="price" class="form-control" required>
                                        <option value="">Select Duration & Price</option>
                                        <option value="5.00">1 Hour - RM 5.00</option>
                                        <option value="10.00">3 Hours - RM 10.00</option>
                                        <option value="15.00">6 Hours - RM 15.00</option>
                                        <option value="20.00">12 Hours - RM 20.00</option>
                                        <option value="25.00">24 Hours - RM 25.00</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <p>By clicking "Book Parking", you agree to the terms and conditions of Tournee Arena.</p>
                                <button type="submit" name="submit" class="btn theme-btn">Book Parking</button>
                            </div>
                        </div>
                    </form>
                </div>
                
                <!-- Display Current Bookings -->
                <div class="widget-heading" style="margin-top: 30px;">
                    <h3 class="widget-title text-dark">
                        Your Current Parking Bookings
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Vehicle Number</th>
                                    <th>Vehicle Type</th>
                                    <th>Entry Time</th>
                                    <th>Parking Slot</th>
                                    <th>Price (RM)</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $user_id = $_SESSION["user_id"];
                                $query = mysqli_query($db, "SELECT * FROM car_parking WHERE u_id='$user_id' ORDER BY parking_id DESC");
                                
                                if(mysqli_num_rows($query) > 0) {
                                    while($row = mysqli_fetch_array($query)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $row['vehicle_number']; ?></td>
                                            <td><?php echo $row['vehicle_type']; ?></td>
                                            <td><?php echo $row['entry_time']; ?></td>
                                            <td><?php echo $row['parking_slot']; ?></td>
                                            <td>RM <?php echo $row['price']; ?></td>
                                            <td>
                                                <?php 
                                                if($row['status'] == 'active') {
                                                    echo '<span class="label label-success">Active</span>';
                                                } elseif($row['status'] == 'cancelled') {
                                                    echo '<span class="label label-warning">Cancelled</span>';
                                                } else {
                                                    echo '<span class="label label-danger">Completed</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php if($row['status'] == 'active') { ?>
                                                    <form method="post" action="" onsubmit="return confirm('Cancel this booking?');" style="display:inline;">
                                                        <input type="hidden" name="cancel_parking_id" value="<?php echo (int)$row['parking_id']; ?>">
                                                        <button type="submit" class="btn btn-warning btn-sm">Cancel</button>
                                                    </form>
                                                <?php } else { echo '-'; } ?>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    echo "<tr><td colspan='7'>No parking bookings found.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>



  <!-- FOOTER SECTION ----------------------- -->
  <section class="footerSection">
    <div class="contentContainer container">
        <div class="footerIntro">
            <div class="footerLogoDiv">
                <span class="hotelName">
                    123Parking<span>..</span>
                </span>
            </div>
            <p>We are a trusted company in unity to provide quality  scrim and service to every customer.</p>

            <div class="footContactDetails">
                <div class="info">
                    <div class="iconDiv"><i class='bx bx-mail-send' ></i></div>
                    <span>123Parking@gmail.com</span>
                </div> 

                <div class="info">
                    <div class="iconDiv"><i class='bx bxs-phone-outgoing'></i></div>
                    <span>+60 198765432</span>
                </div>

                <div class="info">
                    <div class="iconDiv"><i class='bx bx-current-location' ></i></div>
                    <span>Cheras Kuala Lumpur</span>
                </div>
            </div>
        </div>




    </div>
    <div class="copyrightDiv">
       &copy; ..
    </div>
</section>
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
    <script src="js/isratech.js"></script>

</body>

</html>