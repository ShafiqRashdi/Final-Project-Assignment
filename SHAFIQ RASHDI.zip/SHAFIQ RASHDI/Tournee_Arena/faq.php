<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
error_reporting(0);
session_start();
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Welcome To 123Parking</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet"> 
    <link href="footer.css" rel="stylesheet">
</head>
<body class="home">

    
        <!--header starts-->
        <header id="header" class="header-scroll top-header headrom headerBg">
            <!-- .navbar -->
            <nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.php"> 123Parking<span>..</span> </a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                        
                            <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
    
                        <li class="nav-item"> <a class="nav-link active" href="car_parking.php">Car Parking <span class="sr-only"></span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="about.php">About Us <span class="sr-only"></span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="faq.php">FAQ <span class="sr-only"></span></a> </li>

                            
                            
                           
							<?php
						if(empty($_SESSION["user_id"])) // if user is not login
							{
								echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
							  <li class="nav-item"><a href="registration.php" class="nav-link active bgGreen">Signup</a> </li>';
							}
						else
							{
									//if user is login
									
									echo  '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Booking</a> </li>';
									echo  '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
							}

						?>

                        <li class="nav-item"> <a class="nav-link active" href="/Tournee_Arena/Admin/dashboard.php">Admin <span class="sr-only"></span></a> </li>
							 
                        </ul>
						 
                    </div>
                </div>
            </nav>
            <!-- /.navbar -->
        </header>

    <div class="page-wrapper">
        <!-- Breadcrumbs -->
        <div class="top-links">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item"><span>1</span><a href="index.php">Home</a></li>
                    <li class="col-xs-12 col-sm-4 link-item active"><span>2</span><a href="faq.php">FAQ</a></li>
                </ul>
            </div>
        </div>

        <!-- FAQ Content -->
        <section class="container" style="padding: 30px 0;">
            <h2>Frequently Asked Questions</h2>
            <p class="lead">Answers to common questions about booking and parking.</p>

            <div id="faqAccordion" role="tablist" aria-multiselectable="true">
                <div class="card">
                    <div class="card-header" role="tab" id="headingOne">
                        <h5 class="mb-0">
                            <a data-toggle="collapse" data-parent="#faqAccordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                How do I book a parking slot?
                            </a>
                        </h5>
                    </div>
                    <div id="collapseOne" class="collapse in" role="tabpanel" aria-labelledby="headingOne">
                        <div class="card-block">
                            Go to the <a href="car_parking.php">Car Parking</a> page, fill in your vehicle details, choose a slot and duration, then click "Book Parking".
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header" role="tab" id="headingTwo">
                        <h5 class="mb-0">
                            <a class="collapsed" data-toggle="collapse" data-parent="#faqAccordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Can I cancel my booking?
                            </a>
                        </h5>
                    </div>
                    <div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo">
                        <div class="card-block">
                            You can cancel active bookings from the <a href="your_orders.php">My Booking</a> page. Changing bookings is not supported.
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header" role="tab" id="headingThree">
                        <h5 class="mb-0">
                            <a class="collapsed" data-toggle="collapse" data-parent="#faqAccordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                What payment methods are supported?
                            </a>
                        </h5>
                    </div>
                    <div id="collapseThree" class="collapse" role="tabpanel" aria-labelledby="headingThree">
                        <div class="card-block">
                            We support standard online payments. Pricing is shown clearly on the booking page.
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header" role="tab" id="headingFour">
                        <h5 class="mb-0">
                            <a class="collapsed" data-toggle="collapse" data-parent="#faqAccordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Is my vehicle safe while parked?
                            </a>
                        </h5>
                    </div>
                    <div id="collapseFour" class="collapse" role="tabpanel" aria-labelledby="headingFour">
                        <div class="card-block">
                            Yes, our parking locations are monitored and managed to ensure safety and security.
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

  <!-- FOOTER SECTION ----------------------- -->
  <section class="footerSection">
    <div class="contentContainer container">
        <div class="footerIntro">
            <div class="footerLogoDiv">
                <span class="hotelName">
                    123Parking<span>..</span>
                </span>
            </div>
            <p>We are a trusted company in unity to provide quality  scrim and service to every customer.</p>

            <div class="footContactDetails">
                <div class="info">
                    <div class="iconDiv"><i class='bx bx-mail-send' ></i></div>
                    <span>123Parking@gmail.com</span>
                </div> 

                <div class="info">
                    <div class="iconDiv"><i class='bx bxs-phone-outgoing'></i></div>
                    <span>+60 198765432</span>
                </div>

                <div class="info">
                    <div class="iconDiv"><i class='bx bx-current-location' ></i></div>
                    <span>Cheras Kuala Lumpur</span>
                </div>
            </div>
        </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
    <script src="js/isratech.js"></script>
</body>
</html>