-- Table structure for table `simcard`
CREATE TABLE `simcard` (
  `simcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `plan_type` varchar(50) NOT NULL,
  `data_amount` varchar(20) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`simcard_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;