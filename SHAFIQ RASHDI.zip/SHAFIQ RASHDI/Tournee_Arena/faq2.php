<?php
include("connection/connect.php");
error_reporting(0);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="123Parking FAQ Page">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>123Parking - Frequently Asked Questions</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .faq-header {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
            text-align: center;
        }
        
        .faq-header h1 {
            font-weight: 700;
            font-size: 2.8rem;
            margin-bottom: 15px;
        }
        
        .faq-header p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto;
        }
        
        .faq-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .faq-category {
            margin-bottom: 40px;
        }
        
        .faq-category h2 {
            color: #2E7D32;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .faq-item {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .faq-item:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        
        .faq-question {
            padding: 20px;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .faq-question:after {
            content: '\f107';
            font-family: 'FontAwesome';
            color: #4CAF50;
            transition: all 0.3s;
        }
        
        .faq-question.active:after {
            transform: rotate(180deg);
        }
        
        .faq-answer {
            padding: 0 20px;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            border-top: 1px solid #f0f0f0;
        }
        
        .faq-answer.show {
            padding: 20px;
            max-height: 500px;
        }
        
        .faq-answer p {
            margin-bottom: 15px;
        }
        
        .faq-answer a {
            color: #4CAF50;
            text-decoration: none;
            font-weight: 500;
        }
        
        .faq-answer a:hover {
            text-decoration: underline;
        }
        
        .search-container {
            margin-bottom: 30px;
        }
        
        .search-box {
            width: 100%;
            padding: 15px;
            border-radius: 30px;
            border: 1px solid #ddd;
            font-size: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }
        
        .search-box:focus {
            outline: none;
            box-shadow: 0 2px 15px rgba(76,175,80,0.2);
            border-color: #4CAF50;
        }
        
        .contact-section {
            background-color: #e8f5e9;
            padding: 40px;
            border-radius: 8px;
            text-align: center;
            margin-top: 40px;
        }
        
        .contact-section h3 {
            color: #2E7D32;
            margin-bottom: 20px;
        }
        
        .btn-contact {
            background-color: #4CAF50;
            color: white;
            padding: 10px 25px;
            border-radius: 30px;
            font-weight: 600;
            border: none;
            transition: all 0.3s;
        }
        
        .btn-contact:hover {
            background-color: #2E7D32;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(46,125,50,0.3);
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header id="header" class="header-scroll top-header headrom headerBg">
        <nav class="navbar navbar-dark">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php"> 123Parking<span>..</span> </a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="car_parking.php">Car Parking</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="about.php">About Us</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="faq.php">FAQ</a> </li>
                        <?php
                        if(empty($_SESSION["user_id"])) { // if user is not login
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
                            <li class="nav-item"><a href="registration.php" class="nav-link active bgGreen">Signup</a> </li>';
                        } else {
                            // if user is login
                            echo '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Booking</a> </li>';
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- FAQ Header -->
    <div class="faq-header">
        <div class="container">
            <h1>Frequently Asked Questions</h1>
            <p>Find answers to the most common questions about our parking services</p>
        </div>
    </div>

    <!-- FAQ Content -->
    <div class="faq-container">
        <!-- Search Box -->
        <div class="search-container">
            <input type="text" class="search-box" id="faqSearch" placeholder="Search for questions..." onkeyup="searchFAQ()">
        </div>

        <!-- Booking FAQs -->
        <div class="faq-category">
            <h2>Booking Information</h2>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleAnswer(this)">How do I book a parking slot?</div>
                <div class="faq-answer">
                    <p>Booking a parking slot is simple:</p>
                    <ol>
                        <li>Go to the <a href="car_parking.php">Car Parking</a> page</li>
                        <li>Fill in your vehicle details (number and type)</li>
                        <li>Choose your preferred parking slot</li>
                        <li>Review the pricing information</li>
                        <li>Click "Book Parking" to confirm your reservation</li>
                    </ol>
                    <p>You'll receive a confirmation immediately on the screen.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleAnswer(this)">Can I cancel my booking?</div>
                <div class="faq-answer">
                    <p>Yes, you can cancel active bookings from the <a href="your_orders.php">My Booking</a> page. Simply find your active booking and click the "Cancel" button.</p>
                    <p>Please note that only active bookings can be cancelled. Completed bookings cannot be modified. We currently do not support changing booking details - if you need different arrangements, please cancel your current booking and create a new one.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleAnswer(this)">What payment methods are supported?</div>
                <div class="faq-answer">
                    <p>We support various payment methods for your convenience:</p>
                    <ul>
                        <li>Credit/Debit Cards</li>
                        <li>Online Banking</li>
                        <li>E-Wallets</li>
                    </ul>
                    <p>All pricing is shown clearly on the booking page before you confirm your reservation.</p>
                </div>
            </div>
        </div>

        <!-- Security FAQs -->
        <div class="faq-category">
            <h2>Security & Safety</h2>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleAnswer(this)">Is my vehicle safe while parked?</div>
                <div class="faq-answer">
                    <p>Yes, we take security very seriously. Our parking facilities include:</p>
                    <ul>
                        <li>24/7 CCTV surveillance</li>
                        <li>Regular security patrols</li>
                        <li>Well-lit parking areas</li>
                        <li>Controlled access points</li>
                    </ul>
                    <p>We maintain high standards to ensure your vehicle remains safe throughout its stay.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleAnswer(this)">What happens if my vehicle is damaged?</div>
                <div class="faq-answer">
                    <p>In the unlikely event that your vehicle sustains damage while in our parking facility:</p>
                    <ol>
                        <li>Report the incident immediately to our on-site staff</li>
                        <li>Document the damage with photos</li>
                        <li>Fill out an incident report form</li>
                        <li>Our team will review CCTV footage</li>
                        <li>We'll work with you to resolve the situation according to our terms of service</li>
                    </ol>
                    <p>For full details on our liability policy, please contact our customer service.</p>
                </div>
            </div>
        </div>

        <!-- Account FAQs -->
        <div class="faq-category">
            <h2>Account & Membership</h2>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleAnswer(this)">How do I create an account?</div>
                <div class="faq-answer">
                    <p>Creating an account is easy:</p>
                    <ol>
                        <li>Click on the <a href="registration.php">Signup</a> button in the top menu</li>
                        <li>Fill in your personal details</li>
                        <li>Create a secure password</li>
                        <li>Verify your email address</li>
                        <li>Start booking parking spaces!</li>
                    </ol>
                    <p>Having an account allows you to track your bookings and manage your parking history.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleAnswer(this)">How can I view my booking history?</div>
                <div class="faq-answer">
                    <p>You can view your complete booking history by:</p>
                    <ol>
                        <li>Logging into your account</li>
                        <li>Navigating to the <a href="your_orders.php">My Booking</a> page</li>
                    </ol>
                    <p>This page displays all your current and past bookings, including parking slots, dates, and status information.</p>
                </div>
            </div>
        </div>

        <!-- Contact Section -->
        <div class="contact-section">
            <h3>Couldn't find what you're looking for?</h3>
            <p>Our customer support team is ready to help with any other questions you might have.</p>
            <a href="mailto:123Parking@gmail.com" class="btn btn-contact">Contact Support</a>
        </div>
    </div>

    <!-- Footer -->
    <section class="footerSection">
        <div class="contentContainer container">
            <div class="row">
                <div class="col-md-4">
                    <div class="footerLogoDiv">
                        <span class="hotelName">123Parking<span>..</span></span>
                    </div>
                    <p>We are a trusted company committed to quality service for every customer.</p>
                </div>
                <div class="col-md-4">
                    <div class="footContactDetails">
                        <div class="info"><div class="iconDiv"><i class="fa fa-envelope-o"></i></div><span>123Parking@gmail.com</span></div>
                        <div class="info"><div class="iconDiv"><i class="fa fa-phone"></i></div><span>+60 198765432</span></div>
                        <div class="info"><div class="iconDiv"><i class="fa fa-map-marker"></i></div><span>Cheras Kuala Lumpur</span></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-right">
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="index.php">Home</a></li>
                            <li class="list-inline-item"><a href="about.php">About</a></li>
                            <li class="list-inline-item"><a href="car_parking.php">Parking</a></li>
                            <li class="list-inline-item"><a href="faq.php">FAQ</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center py-3" style="background-color: rgba(0,0,0,0.05);">
            &copy; 2023 123Parking. All rights reserved.
        </div>
    </section>

    <!-- JavaScript -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
    
    <script>
        function toggleAnswer(element) {
            element.classList.toggle("active");
            var answer = element.nextElementSibling;
            answer.classList.toggle("show");
        }
        
        function searchFAQ() {
            var input, filter, faqItems, question, i, txtValue;
            input = document.getElementById("faqSearch");
            filter = input.value.toUpperCase();
            faqItems = document.getElementsByClassName("faq-item");
            
            for (i = 0; i < faqItems.length; i++) {
                question = faqItems[i].getElementsByClassName("faq-question")[0];
                txtValue = question.textContent || question.innerText;
                
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    faqItems[i].style.display = "";
                } else {
                    faqItems[i].style.display = "none";
                }
            }
        }
        
        // Initialize - open first FAQ item
        document.addEventListener("DOMContentLoaded", function() {
            var firstQuestion = document.querySelector(".faq-question");
            if (firstQuestion) {
                firstQuestion.click();
            }
        });
    </script>
</body>
</html>