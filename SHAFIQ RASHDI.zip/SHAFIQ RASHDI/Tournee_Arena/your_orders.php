<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if(empty($_SESSION['user_id']))  //if usser is not login redirected baack to login page
{
	header('location:login.php');
}
else
{
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>My Booking</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="footer.css" rel="stylesheet"> 
<style type="text/css" rel="stylesheet">


.indent-small {
  margin-left: 5px;
}
.form-group.internal {
  margin-bottom: 0;
}
.dialog-panel {
  margin: 10px;
}
.datepicker-dropdown {
  z-index: 200 !important;
}
.panel-body {
  background: #e5e5e5;
  /* Old browsers */
  background: -moz-radial-gradient(center, ellipse cover, #e5e5e5 0%, #ffffff 100%);
  /* FF3.6+ */
  background: -webkit-gradient(radial, center center, 0px, center center, 100%, color-stop(0%, #e5e5e5), color-stop(100%, #ffffff));
  /* Chrome,Safari4+ */
  background: -webkit-radial-gradient(center, ellipse cover, #e5e5e5 0%, #ffffff 100%);
  /* Chrome10+,Safari5.1+ */
  background: -o-radial-gradient(center, ellipse cover, #e5e5e5 0%, #ffffff 100%);
  /* Opera 12+ */
  background: -ms-radial-gradient(center, ellipse cover, #e5e5e5 0%, #ffffff 100%);
  /* IE10+ */
  background: radial-gradient(ellipse at center, #e5e5e5 0%, #ffffff 100%);
  /* W3C */
  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#e5e5e5', endColorstr='#ffffff', GradientType=1);
  /* IE6-9 fallback on horizontal gradient */
  font: 600 15px "Open Sans", Arial, sans-serif;
}
label.control-label {
  font-weight: 600;
  color: #777;
}


table { 
	width: 750px; 
	border-collapse: collapse; 
	margin: auto;
	
	}

/* Zebra striping */
tr:nth-of-type(odd) { 
	background: #eee; 
	}

th { 
	background: rgb(0, 188, 126);
	color: white; 
	font-weight: bold; 
	
	}

td, th { 
	padding: 10px; 
	border: 1px solid #ccc; 
	text-align: left; 
	font-size: 14px;
	
	}

/* 
Max width before this PARTICULAR table gets nasty
This query will take effect for any screen smaller than 760px
and also iPads specifically.
*/
@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	table { 
	  	width: 100%; 
	}

	/* Force table to not be like tables anymore */
	table, thead, tbody, th, td, tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	tr { border: 1px solid #ccc; }
	
	td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
	}

	td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		/* Label the data */
		content: attr(data-column);

		color: #000;
		font-weight: bold;
	}

}







	</style>

	</head>

<body>
    
        <!--header starts-->
        <header id="header" class="header-scroll top-header headrom headerBg">
            <!-- .navbar -->
            <nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.php"> 123Parking<span>..</span> </a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                        
                            <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
    
                        <li class="nav-item"> <a class="nav-link active" href="car_parking.php">Car Parking <span class="sr-only"></span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="about.php">About Us <span class="sr-only"></span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="faq.php">FAQ <span class="sr-only"></span></a> </li>

                            
                            
                           
							<?php
						if(empty($_SESSION["user_id"])) // if user is not login
							{
								echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
							  <li class="nav-item"><a href="registration.php" class="nav-link active bgGreen">Signup</a> </li>';
							}
						else
							{
									//if user is login
									
									echo  '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Booking</a> </li>';
									echo  '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
							}

						?>

                        <li class="nav-item"> <a class="nav-link active" href="/Tournee_Arena/Admin/dashboard.php">Admin <span class="sr-only"></span></a> </li>
							 
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- /.navbar -->
        </header>
        <div class="page-wrapper">
            <!-- top Links -->
           
            <!-- end:Top links -->
            <!-- start: Inner page hero -->
            <div class="inner-page-hero bg-image" data-image-src="images/room.jpg">
                <div class="container"> </div>
                <!-- end:Container -->
            </div>
            <div class="result-show">
                <div class="container">
                    <div class="row">
                       
                       
                    </div>
                </div>
            </div>
            <!-- //results show -->
            <section class="restaurants-page">
                <div class="container">
                    <?php
                    // Handle cancel booking for Car Parking on My Booking page
                    if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_parking_id'])) {
                        $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
                        $parking_id = intval($_POST['cancel_parking_id']);
                        if($user_id > 0 && $parking_id > 0) {
                            $stmt = mysqli_prepare($db, "UPDATE car_parking SET status='cancelled', exit_time=NOW() WHERE parking_id=? AND u_id=? AND status='active'");
                            if($stmt) {
                                mysqli_stmt_bind_param($stmt, "ii", $parking_id, $user_id);
                                mysqli_stmt_execute($stmt);
                                if(mysqli_stmt_affected_rows($stmt) > 0) {
                                    $success = "Your parking booking has been cancelled.";
                                } else {
                                    $error = "Unable to cancel. It may already be cancelled or completed.";
                                }
                                mysqli_stmt_close($stmt);
                            } else {
                                $error = "Cancellation failed due to a server error.";
                            }
                        } else {
                            $error = "Invalid request.";
                        }
                    }
                    if(isset($success)) {
                        echo '<div class="alert alert-success"><strong>Success!</strong> '.htmlspecialchars($success).'</div>';
                    }
                    if(isset($error)) {
                        echo '<div class="alert alert-danger"><strong>Error!</strong> '.htmlspecialchars($error).'</div>';
                    }
                    ?>
                    <div class="row">
                        <div class="col-xs-12 col-sm-5 col-md-5 col-lg-3">
                          
                          

                        </div>
                        <div class="col-xs-12 col-sm-7 col-md-7 ">
                            <div class="bg-gray restaurant-entry">
                                <div class="row">
								
                            <table >
                          <thead>
                            <tr>
                            
                              <th>Service</th>
                              <th>Details</th>
                              <th>Price (RM)</th>
                              <th>Status</th>
                              <th>Date</th>
                              <th>Action</th>
                            
                            </tr>
                          </thead>
                          <tbody>
                          
                          
                            <?php 
                            $user_id = $_SESSION["user_id"];
                            $hasRows = false;
                            
                            // Car Parking
                            $query = mysqli_query($db, "SELECT * FROM car_parking WHERE u_id='$user_id' ORDER BY parking_id DESC");
                            while($row = mysqli_fetch_array($query)) { $hasRows = true; ?>
                            <tr>
                              <td data-column="Service">Car Parking</td>
                              <td data-column="Details"><?php echo $row['vehicle_number'].' | '.$row['vehicle_type'].' | Slot '.$row['parking_slot']; ?></td>
                              <td data-column="Price">RM <?php echo $row['price']; ?></td>
                              <td data-column="Status"><?php echo ucfirst($row['status']); ?></td>
                              <td data-column="Date"><?php echo $row['entry_time']; ?></td>
                              <td data-column="Action">
                                <?php if($row['status'] == 'active') { ?>
                                  <form method="post" action="" onsubmit="return confirm('Cancel this booking?');" style="display:inline;">
                                    <input type="hidden" name="cancel_parking_id" value="<?php echo (int)$row['parking_id']; ?>">
                                    <button type="submit" class="btn btn-warning btn-sm">Cancel</button>
                                  </form>
                                <?php } else { echo '-'; } ?>
                              </td>
                            </tr>
                            <?php } ?>
                            
                            <?php 
                            // Simcards
                            $query = mysqli_query($db, "SELECT * FROM simcard WHERE u_id='$user_id' ORDER BY order_date DESC");
                            while($row = mysqli_fetch_array($query)) { $hasRows = true; ?>
                            <tr>
                              <td data-column="Service">Simcards</td>
                              <td data-column="Details"><?php echo $row['phone_number'].' | '.$row['provider'].' | '.$row['plan_type'].' | '.$row['data_amount']; ?></td>
                              <td data-column="Price">RM <?php echo $row['price']; ?></td>
                              <td data-column="Status"><?php echo ucfirst($row['status']); ?></td>
                              <td data-column="Date"><?php echo date('d-m-Y h:i A', strtotime($row['order_date'])); ?></td>
                              <td data-column="Action">-</td>
                            </tr>
                            <?php } ?>
                            
                            <?php 
                            // ML Diamonds
                            $query = mysqli_query($db, "SELECT * FROM ml_diamonds WHERE u_id='$user_id' ORDER BY order_date DESC");
                            while($row = mysqli_fetch_array($query)) { $hasRows = true; ?>
                            <tr>
                              <td data-column="Service">ML Diamonds</td>
                              <td data-column="Details"><?php echo 'Game: '.$row['game_id'].' | Server: '.$row['server_id'].' | '.$row['diamond_amount'].' Diamonds'; ?></td>
                              <td data-column="Price">RM <?php echo $row['price']; ?></td>
                              <td data-column="Status"><?php echo ucfirst($row['status']); ?></td>
                              <td data-column="Date"><?php echo date('d-m-Y h:i A', strtotime($row['order_date'])); ?></td>
                              <td data-column="Action">-</td>
                            </tr>
                            <?php } ?>
                            
                            <?php 
                            // Movie Tickets
                            $query = mysqli_query($db, "SELECT * FROM movie_tickets WHERE u_id='$user_id' ORDER BY order_date DESC");
                            while($row = mysqli_fetch_array($query)) { $hasRows = true; ?>
                            <tr>
                              <td data-column="Service">Movie Tickets</td>
                              <td data-column="Details"><?php echo $row['movie_name'].' @ '.$row['cinema'].' | '.date('d-m-Y', strtotime($row['show_date'])).' '.$row['show_time'].' | '.$row['num_tickets'].' tickets'; ?></td>
                              <td data-column="Price">RM <?php echo $row['price']; ?></td>
                              <td data-column="Status"><?php echo ucfirst($row['status']); ?></td>
                              <td data-column="Date"><?php echo date('d-m-Y h:i A', strtotime($row['order_date'])); ?></td>
                              <td data-column="Action">-</td>
                            </tr>
                            <?php } ?>
                            
                            <?php if(!$hasRows) { echo "<tr><td colspan='6'><center>No bookings or orders yet.</center></td></tr>"; } ?>
                          
                          
                          
                          
                          
                          
                          </tbody>
                    </table
						
					
                                    
                                </div>
                                <!--end:row -->
                            </div>
                         
                            
                                
                            </div>
                          
                          
                           
                        </div>
                    </div>
                </div>
            </section>
       <!-- Featured restaurants ends -->
      



  <!-- FOOTER SECTION ----------------------- -->
  <section class="footerSection">
    <div class="contentContainer container">
        <div class="footerIntro">
            <div class="footerLogoDiv">
                <span class="hotelName">
                    123Parking<span>..</span>
                </span>
            </div>
            <p>We are a trusted company in unity to provide quality  scrim and service to every customer.</p>

            <div class="footContactDetails">
                <div class="info">
                    <div class="iconDiv"><i class='bx bx-mail-send' ></i></div>
                    <span>123Parking@gmail.com</span>
                </div> 

                <div class="info">
                    <div class="iconDiv"><i class='bx bxs-phone-outgoing'></i></div>
                    <span>+60 198765432</span>
                </div>

                <div class="info">
                    <div class="iconDiv"><i class='bx bx-current-location' ></i></div>
                    <span>Cheras Kuala Lumpur</span>
                </div>
            </div>
        </div>

    </div>
    <div class="copyrightDiv">
       &copy; ..
    </div>
</section>
  
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>

</html>
<?php
}
?>