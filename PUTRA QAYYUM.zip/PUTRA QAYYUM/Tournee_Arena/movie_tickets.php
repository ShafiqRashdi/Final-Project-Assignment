<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if(empty($_SESSION["user_id"])) {
    header('location:login.php');
} else {
    // Process form submission
    if(isset($_POST['submit'])) {
        $movie_name = $_POST['movie_name'];
        $cinema = $_POST['cinema'];
        $show_date = $_POST['show_date'];
        $show_time = $_POST['show_time'];
        $num_tickets = $_POST['num_tickets'];
        $seat_numbers = $_POST['seat_numbers'];
        $price = $_POST['price'];
        $user_id = $_SESSION["user_id"];
        
        // Insert into database
        $sql = "INSERT INTO movie_tickets(u_id, movie_name, cinema, show_date, show_time, num_tickets, seat_numbers, price, status) 
                VALUES('$user_id', '$movie_name', '$cinema', '$show_date', '$show_time', '$num_tickets', '$seat_numbers', '$price', 'pending')";
        
        mysqli_query($db, $sql);
        
        $success = "Your movie ticket order has been placed successfully!";
    }
}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Movie Tickets - Tournee Arena</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark bg-dark" style="background-color: rgb(68, 95, 85) !important;">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php"> Da Movie<span>..</span> </a>
                <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="movie_tickets.php">Movie Tickets <span class="sr-only"></span></a> </li>
                        
                        <?php
                        if(empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
                            <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a> </li>';
                        } else {
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    
    <div class="page-wrapper">
        <div class="top-links">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item"><span>1</span><a href="index.php">Home</a></li>
                    <li class="col-xs-12 col-sm-4 link-item active"><span>2</span><a href="movie_tickets.php">Movie Tickets</a></li>
                </ul>
            </div>
        </div>
        
        <div class="container">
            <div class="widget clearfix">
                <div class="widget-heading">
                    <h3 class="widget-title text-dark">
                        Movie Ticket Booking
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <?php
                    if(isset($success)) {
                        echo '<div class="alert alert-success">
                            <strong>Success!</strong> '.$success.'
                        </div>';
                    }
                    ?>
                    
                    <form method="post" action="">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Movie Name</label>
                                    <select name="movie_name" class="form-control" required>
                                        <option value="">Select Movie</option>
                                        <option value="Avengers: Endgame">Avengers: Endgame</option>
                                        <option value="Spider-Man: No Way Home">Spider-Man: No Way Home</option>
                                        <option value="The Batman">The Batman</option>
                                        <option value="Black Panther: Wakanda Forever">Black Panther: Wakanda Forever</option>
                                        <option value="Jurassic World Dominion">Jurassic World Dominion</option>
                                        <option value="Top Gun: Maverick">Top Gun: Maverick</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Cinema</label>
                                    <select name="cinema" class="form-control" required>
                                        <option value="">Select Cinema</option>
                                        <option value="GSC Mid Valley">GSC Mid Valley</option>
                                        <option value="TGV KLCC">TGV KLCC</option>
                                        <option value="MBO The Starling">MBO The Starling</option>
                                        <option value="GSC 1 Utama">GSC 1 Utama</option>
                                        <option value="TGV Sunway Pyramid">TGV Sunway Pyramid</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Show Date</label>
                                    <input type="date" name="show_date" class="form-control" required min="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Show Time</label>
                                    <select name="show_time" class="form-control" required>
                                        <option value="">Select Time</option>
                                        <option value="10:00 AM">10:00 AM</option>
                                        <option value="12:30 PM">12:30 PM</option>
                                        <option value="3:00 PM">3:00 PM</option>
                                        <option value="5:30 PM">5:30 PM</option>
                                        <option value="8:00 PM">8:00 PM</option>
                                        <option value="10:30 PM">10:30 PM</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Number of Tickets</label>
                                    <select name="num_tickets" class="form-control" required>
                                        <option value="">Select Number</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Seat Numbers</label>
                                    <input type="text" name="seat_numbers" class="form-control" placeholder="e.g. A1, A2, A3" required>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Price (RM)</label>
                                    <select name="price" class="form-control" required>
                                        <option value="">Select Price</option>
                                        <option value="15">RM 15 (1 ticket)</option>
                                        <option value="30">RM 30 (2 tickets)</option>
                                        <option value="45">RM 45 (3 tickets)</option>
                                        <option value="60">RM 60 (4 tickets)</option>
                                        <option value="75">RM 75 (5 tickets)</option>
                                        <option value="90">RM 90 (6 tickets)</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <p class="text-info">
                                    <strong>Note:</strong> Your tickets will be available for collection at the cinema 30 minutes before showtime. Please bring your ID for verification.
                                </p>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <input type="submit" name="submit" value="Book Tickets" class="btn btn-primary">
                            </div>
                        </div>
                    </form>
                </div>
                
                <div class="widget-heading mt-4">
                    <h3 class="widget-title text-dark">
                        My Ticket Bookings
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Movie</th>
                                    <th>Cinema</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Tickets</th>
                                    <th>Seats</th>
                                    <th>Price (RM)</th>
                                    <th>Status</th>
                                    <th>Order Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if(!empty($_SESSION["user_id"])) {
                                    $user_id = $_SESSION["user_id"];
                                    $query = mysqli_query($db, "SELECT * FROM movie_tickets WHERE u_id='$user_id' ORDER BY order_date DESC");
                                    
                                    if(mysqli_num_rows($query) > 0) {
                                        while($row = mysqli_fetch_array($query)) {
                                            echo '<tr>
                                                <td>'.$row['movie_name'].'</td>
                                                <td>'.$row['cinema'].'</td>
                                                <td>'.date('d-m-Y', strtotime($row['show_date'])).'</td>
                                                <td>'.$row['show_time'].'</td>
                                                <td>'.$row['num_tickets'].'</td>
                                                <td>'.$row['seat_numbers'].'</td>
                                                <td>'.$row['price'].'</td>
                                                <td>'.ucfirst($row['status']).'</td>
                                                <td>'.date('d-m-Y h:i A', strtotime($row['order_date'])).'</td>
                                            </tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="9" class="text-center">No ticket bookings found</td></tr>';
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include "footer.php"; ?>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>
</html>