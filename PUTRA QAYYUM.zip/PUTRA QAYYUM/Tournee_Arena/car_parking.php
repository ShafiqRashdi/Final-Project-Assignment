<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if(empty($_SESSION["user_id"])) {
    header('location:login.php');
} else {
    // Process form submission
    if(isset($_POST['submit'])) {
        $vehicle_number = $_POST['vehicle_number'];
        $vehicle_type = $_POST['vehicle_type'];
        $parking_slot = $_POST['parking_slot'];
        $entry_time = date('Y-m-d H:i:s');
        $price = $_POST['price'];
        $user_id = $_SESSION["user_id"];
        
        // Insert into database
        $sql = "INSERT INTO car_parking(u_id, vehicle_number, vehicle_type, entry_time, parking_slot, price, status) 
                VALUES('$user_id', '$vehicle_number', '$vehicle_type', '$entry_time', '$parking_slot', '$price', 'active')";
        
        mysqli_query($db, $sql);
        
        $success = "Your parking has been booked successfully!";
    }
}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Car Parking - Tournee Arena</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <header id="header" class="header-scroll top-header headrom ">
        <nav class="navbar navbar-dark bg-dark" style="background-color: rgb(68, 95, 85) !important;">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php"> Tournee Arena<span>..</span> </a>
                <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="car_parking.php">Car Parking <span class="sr-only"></span></a> </li>
                        
                        <?php
                        if(empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
                            <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a> </li>';
                        } else {
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <div class="page-wrapper">
        <div class="top-links">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item"><span>1</span><a href="index.php">Home</a></li>
                    <li class="col-xs-12 col-sm-4 link-item active"><span>2</span><a href="car_parking.php">Car Parking</a></li>
                </ul>
            </div>
        </div>
        
        <div class="container">
            <div class="widget clearfix">
                <div class="widget-heading">
                    <h3 class="widget-title text-dark">
                        Car Parking Booking
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <?php
                    if(isset($success)) {
                        echo '<div class="alert alert-success">
                            <strong>Success!</strong> '.$success.'
                        </div>';
                    }
                    ?>
                    
                    <form method="post" action="">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Vehicle Number</label>
                                    <input type="text" name="vehicle_number" class="form-control" placeholder="Enter Vehicle Number" required>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Vehicle Type</label>
                                    <select name="vehicle_type" class="form-control" required>
                                        <option value="">Select Vehicle Type</option>
                                        <option value="Car">Car</option>
                                        <option value="Motorcycle">Motorcycle</option>
                                        <option value="SUV">SUV</option>
                                        <option value="Van">Van</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Parking Slot</label>
                                    <select name="parking_slot" class="form-control" required>
                                        <option value="">Select Parking Slot</option>
                                        <option value="A1">A1</option>
                                        <option value="A2">A2</option>
                                        <option value="A3">A3</option>
                                        <option value="B1">B1</option>
                                        <option value="B2">B2</option>
                                        <option value="B3">B3</option>
                                        <option value="C1">C1</option>
                                        <option value="C2">C2</option>
                                        <option value="C3">C3</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Price (RM)</label>
                                    <select name="price" class="form-control" required>
                                        <option value="">Select Duration & Price</option>
                                        <option value="5.00">1 Hour - RM 5.00</option>
                                        <option value="10.00">3 Hours - RM 10.00</option>
                                        <option value="15.00">6 Hours - RM 15.00</option>
                                        <option value="20.00">12 Hours - RM 20.00</option>
                                        <option value="25.00">24 Hours - RM 25.00</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <p>By clicking "Book Parking", you agree to the terms and conditions of Tournee Arena.</p>
                                <button type="submit" name="submit" class="btn theme-btn">Book Parking</button>
                            </div>
                        </div>
                    </form>
                </div>
                
                <!-- Display Current Bookings -->
                <div class="widget-heading" style="margin-top: 30px;">
                    <h3 class="widget-title text-dark">
                        Your Current Parking Bookings
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Vehicle Number</th>
                                    <th>Vehicle Type</th>
                                    <th>Entry Time</th>
                                    <th>Parking Slot</th>
                                    <th>Price (RM)</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $user_id = $_SESSION["user_id"];
                                $query = mysqli_query($db, "SELECT * FROM car_parking WHERE u_id='$user_id' ORDER BY parking_id DESC");
                                
                                if(mysqli_num_rows($query) > 0) {
                                    while($row = mysqli_fetch_array($query)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $row['vehicle_number']; ?></td>
                                            <td><?php echo $row['vehicle_type']; ?></td>
                                            <td><?php echo $row['entry_time']; ?></td>
                                            <td><?php echo $row['parking_slot']; ?></td>
                                            <td>RM <?php echo $row['price']; ?></td>
                                            <td>
                                                <?php 
                                                if($row['status'] == 'active') {
                                                    echo '<span class="label label-success">Active</span>';
                                                } else {
                                                    echo '<span class="label label-danger">Completed</span>';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    echo "<tr><td colspan='6'>No parking bookings found.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-4 address color-gray">
                        <h5>Address</h5>
                        <p>Tournee Arena, Jalan Universiti, 50603 Kuala Lumpur</p>
                        <h5>Phone: +60123456789</h5>
                    </div>
                    <div class="col-xs-12 col-sm-5 additional-info color-gray">
                        <h5>Additional Information</h5>
                        <p>Join us for the best gaming experience in town.</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>
</html>