<?php
include("connection/connect.php");
error_reporting(0);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>123Parking - Services FAQ</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        body {
            background-image: url('images/batman.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        
        .faq-container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 5px;
            padding: 30px;
            margin: 50px auto;
            max-width: 900px;
        }
        
        .faq-title {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }
        
        .faq-section {
            margin-bottom: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
        }
        
        .faq-section h3 {
            color: #4CAF50;
            margin-bottom: 15px;
        }
        
        .faq-item {
            margin-bottom: 20px;
        }
        
        .faq-question {
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .faq-answer {
            line-height: 1.6;
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header id="header" class="header-scroll top-header headrom headerBg">
        <nav class="navbar navbar-dark">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php"> Da Movie<span>..</span> </a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="car_parking.php">Car Parking</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="about.php">About Us</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="faq.php">FAQ</a> </li>
                        <?php
                        if(empty($_SESSION["user_id"])) { // if user is not login
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
                            <li class="nav-item"><a href="registration.php" class="nav-link active bgGreen">Signup</a> </li>';
                        } else {
                            // if user is login
                            echo '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Booking</a> </li>';
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="page-wrapper">
        <div class="faq-container">
            <div class="faq-title">
                <h1>Frequently Asked Questions</h1>
                <p>Find answers about our ML Diamonds, Movie Tickets, and Simcard services</p>
            </div>
            
            <!-- ML Diamonds FAQs -->
            
            
            <!-- Movie Tickets FAQs -->
            <div class="faq-section">
                <h3>Movie Tickets</h3>
                
                <div class="faq-item">
                    <div class="faq-question">How do I book movie tickets?</div>
                    <div class="faq-answer">
                        Visit our Movie Tickets page, select your preferred movie, showtime, and seats. Complete the payment process to confirm your booking. You'll receive an e-ticket that you can show at the cinema.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">Can I cancel my movie ticket booking?</div>
                    <div class="faq-answer">
                        Yes, you can cancel active bookings from the My Booking page. Please note that cancellations made less than 24 hours before the showtime may be subject to a cancellation fee.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">Do you offer discounts for group bookings?</div>
                    <div class="faq-answer">
                        Yes, we offer special rates for group bookings of 10 or more tickets. Please contact our customer service for more information about group rates.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">Which cinemas are available for booking?</div>
                    <div class="faq-answer">
                        We partner with major cinema chains across the country. You can see the full list of available cinemas when you select a movie on our booking page.
                    </div>
                </div>
            </div>
            
            <!-- Simcard FAQs -->
            

    <!-- Footer -->
    <section class="footerSection">
        <div class="contentContainer container">
            <div class="row">
                <div class="col-md-4">
                    <div class="footerLogoDiv">
                        <span class="hotelName">Da MOvie<span>..</span></span>
                    </div>
                    <p>We are a trusted company committed to quality service for every customer.</p>
                </div>
                <div class="col-md-4">
                    <div class="footContactDetails">
                        <div class="info"><div class="iconDiv"><i class="fa fa-envelope-o"></i></div><span>Damovie@gmail.com</span></div>
                        <div class="info"><div class="iconDiv"><i class="fa fa-phone"></i></div><span>+60 167981454</span></div>
                        <div class="info"><div class="iconDiv"><i class="fa fa-map-marker"></i></div><span>Cheras Kuala Lumpur</span></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-right">
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="index.php">Home</a></li>
                            <li class="list-inline-item"><a href="about.php">About</a></li>
                            <li class="list-inline-item"><a href="car_parking.php">Parking</a></li>
                            <li class="list-inline-item"><a href="faq.php">FAQ</a></li>
                            <li class="list-inline-item"><a href="faq2.php">FAQ2</a></li>
                            <li class="list-inline-item"><a href="faq3.php">FAQ3</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center py-3" style="background-color: rgba(0,0,0,0.05);">
            &copy; 2023 DaMovie. All rights reserved.
        </div>
    </section>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>
</html>