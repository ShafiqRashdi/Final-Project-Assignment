<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");  //include connection file
error_reporting(0);  // using to hide undefine undex errors
session_start(); //start temp session until logout/browser closed

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Welcome To Tournee Arena</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet"> 
    <link href="footer.css" rel="stylesheet"> 
</head>

<body class="home">
    
        <!--header starts-->
        <header id="header" class="header-scroll top-header headrom headerBg">
            <!-- .navbar -->
            <nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.php"> Da Movie<span>..</span> </a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                        
                            <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
    
                        
                        <li class="nav-item"> <a class="nav-link active" href="movie_tickets.php">Movie Tickets <span class="sr-only"></span></a> </li>
                                                <li class="nav-item"> <a class="nav-link active" href="faq.php">FAQ <span class="sr-only"></span></a> </li>
                            
                            
                           
							<?php
						if(empty($_SESSION["user_id"])) // if user is not login
							{
								echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
							  <li class="nav-item"><a href="registration.php" class="nav-link active bgGreen">Signup</a> </li>';
							}
						else
							{
									//if user is login
									
									echo  '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Booking</a> </li>';
									echo  '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
							}

						?>
							 
                        </ul>
						 
                    </div>
                </div>
            </nav>
            <!-- /.navbar -->
        </header>
        <!-- banner part starts -->
        <section class="hero bg-image" data-image-src="images/img/movie1.jpg.webp">
            <div class="hero-inner">
                <div class="container text-center hero-text font-white">
                    <h1>Welcome To Da Movie </h1>
                    <h5 class="font-white space-xs">Where You can Find Unlimited Movie Tickets</h5>
                    <div class="banner-form">
                        <form class="form-inline">
                            <div class="form-group">
                                <label class="sr-only" for="exampleInputAmount">I would like to eat....</label>
                                <div class="form-group">
                                     </div>
                            </div>
                            
                        </form>
                    </div>
                  
                    
                </div>
            </div>
            <!--end:Hero inner -->
        </section>
        <!-- banner part ends -->
      
        <!-- Popular block starts -->
        <section class="popular">
            <div class="container">
                <div class="title text-xs-center m-b-30" >
                    <h2 class= "title">About Us</h2>
                    <p class="subTitle">Welcome to Da Movie – your ultimate destination for the latest movies, reviews, and streaming recommendations!
Founded in 2025 by a team of passionate film enthusiasts, Da Movie was born out of a love for cinema and a desire to make discovering great films easier and more enjoyable for everyone. Whether you're into blockbuster hits, indie gems, Tamil classics, Hollywood epics, or international hidden treasures, we've got you covered.
Our mission is simple: to connect movie lovers with the best content out there. We curate high-quality streams, provide honest reviews, up-to-date release info, and a user-friendly platform where you can search by genre, language, year, or actor. No more endless scrolling – just pure movie magic!
At Da Movie, we believe movies are more than entertainment; they're stories that inspire, entertain, and bring people together. Join our growing community today and dive into a world of endless cinematic adventures.
Watch. Love. Repeat.</p>
                </div>
                <div class="row">
				
				
				
						<?php 
						// fetch records from database to display popular first 3 dishes from table
						
						
						
						?>
				
                </div>
            </div>
        </section>
        <!-- Popular block ends -->
 <!-- ABOUT  SECTION ===================================================== -->

 <section class="section aboutSection" id ="about">
        <div class="sectionContent container">
           <div class="sectionIntro">
               <div class="headerInfo">
                   <h2 class="title">Top Pick Movie 2025</h2>
                   <p class="subTitle">Box Office Movies </p>
               </div>
           </div>
           <div class="sectionData">
           <div class="leftImg">
              <img src="./images/avenger.jpg" alt="Food Image">
              </div>
              <div class="rightImgs">
                  <div class="rightImg">
                      <img src="./images/spider.jpg" alt="Food Image">
                  </div>
                  <div class="rightImg">
                      <img src="./images/batman.jpg" alt="Food Image">
                  </div>
                  <div class="rightImg">
                      <img src="./images/bp.jpg" alt="Food Image">
                  </div>
                  <div class="rightImg">
                      <img src="./images/jurassic.jpg" alt="Food Image">
                  </div>
                  
              </div>
           </div>
        </div>
    </section>









        <!-- Featured restaurants starts -->
       
                <!-- restaurants listing starts -->
               
                <!-- restaurants listing ends -->
               
            </div>
        </section>
        <!-- Featured restaurants ends -->
        



  <!-- FOOTER SECTION ----------------------- -->
  <section class="footerSection">
    <div class="contentContainer container">
        <div class="footerIntro">
            <div class="footerLogoDiv">
                <span class="hotelName">
                    Da Movie<span>..</span>
                </span>
            </div>
            <p>The Best Movie Online Ticketing System.</p>

            <div class="footContactDetails">
                <div class="info">
                    <div class="iconDiv"><i class='bx bx-mail-send' ></i></div>
                    <span>Damovie@gmail.com</span>
                </div>

                <div class="info">
                    <div class="iconDiv"><i class='bx bxs-phone-outgoing'></i></div>
                    <span>+60 167981454</span>
                </div>

                <div class="info">
                    <div class="iconDiv"><i class='bx bx-current-location' ></i></div>
                    <span>Cheras Kuala Lumpur</span>
                </div>
            </div>
        </div>

        <div class="linksDiv">
            <div class="footersectionTitle">
                <h5>USEFUL LINKS</h5>
            </div>
            <ul>
                <span>Careers</span>
                <span>Offers</span>
                <span>Stuff</span>
                <span>Outlets</span>
                <span>Affiliation</span>
                <span>FAQs</span>
            </ul>
        </div>

        <div class="linksDiv">
            <div class="footersectionTitle">
                <h5>OUR SERVICES</h5>
            </div>
            <ul>
                <span>Online Booking</span>
                
                <span>Return Money</span>
                <span>Booking On Time</span>
                <span>Wishlist</span>
                <span>Discount</span>
            </ul>
        </div>

        <div class="linksDiv footerForm">
            <div class="footersectionTitle">
                <h5> OUR NEWSLETTER</h5>
            </div>
             
            <form action="">
                <label> Subscribe To Our Newsletter...</label>
                <input type="text" placeholder="Name" required>
                <input type="email" placeholder="Email" required>
                <button type="submit">Submit</button>
            </form>
        </div>

    </div>
    <div class="copyrightDiv">
       &copy; ..
    </div>
</section>
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
    <script src="js/isratech.js"></script>

</body>

</html>