<!DOCTYPE html>
<html lang="en">
<?php
include("../connection/connect.php");
error_reporting(0);
session_start();

if(empty($_SESSION["adm_id"])) {
    header('location:index.php');
} else {
    // Process status update
    if(isset($_POST['update_status'])) {
        $ticket_id = $_POST['ticket_id'];
        $status = $_POST['status'];
        
        $sql = "UPDATE movie_tickets SET status='$status' WHERE ticket_id='$ticket_id'";
        mysqli_query($db, $sql);
        
        $success = "Ticket status updated successfully!";
    }
}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title>All Movie Tickets</title>
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body class="fix-header fix-sidebar">
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" />
        </svg>
    </div>
    
    <div id="main-wrapper">
        <?php include("header.php"); ?>
        <?php include("sidebar.php"); ?>
        
        <div class="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="col-lg-12">
                            <div class="card card-outline-primary">
                                <div class="card-header">
                                    <h4 class="m-b-0 text-white">All Movie Ticket Orders</h4>
                                </div>
                                
                                <div class="card-body">
                                    <?php
                                    if(isset($success)) {
                                        echo '<div class="alert alert-success">
                                            <strong>Success!</strong> '.$success.'
                                        </div>';
                                    }
                                    ?>
                                    
                                    <div class="table-responsive m-t-40">
                                        <table id="myTable" class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>User</th>
                                                    <th>Movie</th>
                                                    <th>Cinema</th>
                                                    <th>Date</th>
                                                    <th>Time</th>
                                                    <th>Tickets</th>
                                                    <th>Seats</th>
                                                    <th>Price (RM)</th>
                                                    <th>Status</th>
                                                    <th>Order Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sql = "SELECT t.*, u.username FROM movie_tickets t JOIN users u ON t.u_id = u.u_id ORDER BY t.order_date DESC";
                                                $query = mysqli_query($db, $sql);
                                                
                                                if(mysqli_num_rows($query) > 0) {
                                                    while($row = mysqli_fetch_array($query)) {
                                                        echo '<tr>
                                                            <td>'.$row['ticket_id'].'</td>
                                                            <td>'.$row['username'].'</td>
                                                            <td>'.$row['movie_name'].'</td>
                                                            <td>'.$row['cinema'].'</td>
                                                            <td>'.date('d-m-Y', strtotime($row['show_date'])).'</td>
                                                            <td>'.$row['show_time'].'</td>
                                                            <td>'.$row['num_tickets'].'</td>
                                                            <td>'.$row['seat_numbers'].'</td>
                                                            <td>'.$row['price'].'</td>
                                                            <td>'.ucfirst($row['status']).'</td>
                                                            <td>'.date('d-m-Y h:i A', strtotime($row['order_date'])).'</td>
                                                            <td>
                                                                <form method="post" action="">
                                                                    <input type="hidden" name="ticket_id" value="'.$row['ticket_id'].'">
                                                                    <select name="status" class="form-control" required>
                                                                        <option value="">Select Status</option>
                                                                        <option value="pending" '.($row['status'] == 'pending' ? 'selected' : '').'>Pending</option>
                                                                        <option value="confirmed" '.($row['status'] == 'confirmed' ? 'selected' : '').'>Confirmed</option>
                                                                        <option value="cancelled" '.($row['status'] == 'cancelled' ? 'selected' : '').'>Cancelled</option>
                                                                    </select>
                                                                    <button type="submit" name="update_status" class="btn btn-primary btn-sm mt-1">Update</button>
                                                                </form>
                                                            </td>
                                                        </tr>';
                                                    }
                                                } else {
                                                    echo '<tr><td colspan="12" class="text-center">No movie ticket orders found</td></tr>';
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/lib/datatables/datatables.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="js/lib/datatables/cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script src="js/lib/datatables/datatables-init.js"></script>
</body>
</html>