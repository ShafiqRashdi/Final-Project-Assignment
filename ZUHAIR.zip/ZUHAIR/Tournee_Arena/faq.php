<?php
include("connection/connect.php");
error_reporting(0);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>MySimcard - Services FAQ</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    
    <style>
        body {
            background-image: url('images/img/background2.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        
        .faq-container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 5px;
            padding: 30px;
            margin: 50px auto;
            max-width: 900px;
        }
        
        .faq-title {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }
        
        .faq-section {
            margin-bottom: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
        }
        
        .faq-section h3 {
            color: #4CAF50;
            margin-bottom: 15px;
        }
        
        .faq-item {
            margin-bottom: 20px;
        }
        
        .faq-question {
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .faq-answer {
            line-height: 1.6;
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header id="header" class="header-scroll top-header headrom headerBg">
        <nav class="navbar navbar-dark">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php"> Mysimcard<span>..</span> </a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="simcard.php">Simcard</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="faq.php">FAQ</a> </li>
                        <?php
                        if(empty($_SESSION["user_id"])) { // if user is not login
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
                            <li class="nav-item"><a href="registration.php" class="nav-link active bgGreen">Signup</a> </li>';
                        } else {
                            // if user is login
                            
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="page-wrapper">
        <div class="faq-container">
            <div class="faq-title">
                <h1>Frequently Asked Questions</h1>
                <p>Find answers about our ML Diamonds, Movie Tickets, and Simcard services</p>
            </div>
            
           
            
            <!-- Simcard FAQs -->
            <div class="faq-section">
                <h3>Simcards</h3>
                
                <div class="faq-item">
                    <div class="faq-question">What types of simcards do you offer?</div>
                    <div class="faq-answer">
                        We offer prepaid and postpaid simcards from major telecommunications providers. Our selection includes data-only plans, voice and data plans, and tourist simcards with special rates.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">How do I activate my new simcard?</div>
                    <div class="faq-answer">
                        Activation instructions are included with each simcard. Generally, you'll need to insert the simcard into your phone and follow the provider's activation process, which typically involves dialing a specific number or sending an SMS.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">Can I port my existing number to a new simcard?</div>
                    <div class="faq-answer">
                        Yes, number portability is supported. When ordering, select the "Port Existing Number" option and provide your current number and service provider details. The porting process typically takes 1-3 business days.
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question">What should I do if my simcard is not working?</div>
                    <div class="faq-answer">
                        First, ensure that the simcard is properly inserted and activated. If issues persist, contact our customer support with your order details, and we'll help troubleshoot or arrange a replacement if necessary.
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-4">
                <p>Still have questions? Contact our support team at <strong>Mysimcard@gmail.com</strong> or call <strong>+60 198765432</strong></p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <section class="footerSection">
        <div class="contentContainer container">
            <div class="row">
                <div class="col-md-4">
                    <div class="footerLogoDiv">
                        <span class="hotelName">Mysimcard<span>..</span></span>
                    </div>
                    <p>We are a trusted company committed to quality service for every customer.</p>
                </div>
                <div class="col-md-4">
                    <div class="footContactDetails">
                        <div class="info"><div class="iconDiv"><i class="fa fa-envelope-o"></i></div><span>Mysimcard@gmail.com</span></div>
                        <div class="info"><div class="iconDiv"><i class="fa fa-phone"></i></div><span>+60 1231234221</span></div>
                        <div class="info"><div class="iconDiv"><i class="fa fa-map-marker"></i></div><span>Cheras Kuala Lumpur</span></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-right">
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="index.php">Home</a></li>
                            <li class="list-inline-item"><a href="about.php">About</a></li>
                            <li class="list-inline-item"><a href="car_parking.php">Simcard</a></li>
                            <li class="list-inline-item"><a href="faq.php">FAQ</a></li>
                            <li class="list-inline-item"><a href="faq2.php">FAQ2</a></li>
                            <li class="list-inline-item"><a href="faq3.php">FAQ3</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center py-3" style="background-color: rgba(0,0,0,0.05);">
            &copy; 2023 Mysimcard. All rights reserved.
        </div>
    </section>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>
</html>