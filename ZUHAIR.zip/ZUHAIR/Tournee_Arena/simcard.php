<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if(empty($_SESSION["user_id"])) {
    header('location:login.php');
} else {
    // Process form submission
    if(isset($_POST['submit'])) {
        $phone_number = $_POST['phone_number'];
        $provider = $_POST['provider'];
        $plan_type = $_POST['plan_type'];
        $data_amount = $_POST['data_amount'];
        $price = $_POST['price'];
        $user_id = $_SESSION["user_id"];
        
        // Insert into database
        $sql = "INSERT INTO simcard(u_id, phone_number, provider, plan_type, data_amount, price, status) 
                VALUES('$user_id', '$phone_number', '$provider', '$plan_type', '$data_amount', '$price', 'pending')";
        
        mysqli_query($db, $sql);
        
        $success = "Your simcard has been ordered successfully!";
    }
}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Simcard - Tournee Arena</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark bg-dark" style="background-color: rgb(68, 95, 85) !important;">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
               <a class="navbar-brand" href="index.php"> Tournee Arena<span>..</span> </a>
                <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="simcard.php">Simcard <span class="sr-only"></span></a> </li>
                        
                        <?php
                        if(empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a> </li>
                            <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a> </li>';
                        } else {
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    
    <div class="page-wrapper">
        <div class="top-links">
            <div class="container">
                <ul class="row links">
                    <li class="col-xs-12 col-sm-4 link-item"><span>1</span><a href="index.php">Home</a></li>
                    <li class="col-xs-12 col-sm-4 link-item active"><span>2</span><a href="simcard.php">Simcard</a></li>
                </ul>
            </div>
        </div>
        
        <div class="container">
            <div class="widget clearfix">
                <div class="widget-heading">
                    <h3 class="widget-title text-dark">
                        Simcard Order
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <?php
                    if(isset($success)) {
                        echo '<div class="alert alert-success">
                            <strong>Success!</strong> '.$success.'
                        </div>';
                    }
                    ?>
                    
                    <form method="post" action="">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Phone Number</label>
                                    <input type="text" name="phone_number" class="form-control" placeholder="Enter phone number" required>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Provider</label>
                                    <select name="provider" class="form-control" required>
                                        <option value="">Select Provider</option>
                                        <option value="Maxis">Maxis</option>
                                        <option value="Digi">Digi</option>
                                        <option value="Celcom">Celcom</option>
                                        <option value="UMobile">UMobile</option>
                                        <option value="Yes">Yes</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Plan Type</label>
                                    <select name="plan_type" class="form-control" required>
                                        <option value="">Select Plan Type</option>
                                        <option value="Prepaid">Prepaid</option>
                                        <option value="Postpaid">Postpaid</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Data Amount</label>
                                    <select name="data_amount" class="form-control" required>
                                        <option value="">Select Data Amount</option>
                                        <option value="5GB">5GB</option>
                                        <option value="10GB">10GB</option>
                                        <option value="20GB">20GB</option>
                                        <option value="30GB">30GB</option>
                                        <option value="Unlimited">Unlimited</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Price (RM)</label>
                                    <select name="price" class="form-control" required>
                                        <option value="">Select Price</option>
                                        <option value="30">RM 30</option>
                                        <option value="50">RM 50</option>
                                        <option value="80">RM 80</option>
                                        <option value="100">RM 100</option>
                                        <option value="150">RM 150</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <p class="text-info">
                                    <strong>Note:</strong> Your simcard will be processed and available for pickup at our counter within 24 hours.
                                </p>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <input type="submit" name="submit" value="Order Simcard" class="btn btn-primary">
                            </div>
                        </div>
                    </form>
                </div>
                
                <div class="widget-heading mt-4">
                    <h3 class="widget-title text-dark">
                        My Simcard Orders
                    </h3>
                    <div class="clearfix"></div>
                </div>
                
                <div class="widget-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Phone Number</th>
                                    <th>Provider</th>
                                    <th>Plan Type</th>
                                    <th>Data Amount</th>
                                    <th>Price (RM)</th>
                                    <th>Status</th>
                                    <th>Order Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if(!empty($_SESSION["user_id"])) {
                                    $user_id = $_SESSION["user_id"];
                                    $query = mysqli_query($db, "SELECT * FROM simcard WHERE u_id='$user_id' ORDER BY order_date DESC");
                                    
                                    if(mysqli_num_rows($query) > 0) {
                                        while($row = mysqli_fetch_array($query)) {
                                            echo '<tr>
                                                <td>'.$row['phone_number'].'</td>
                                                <td>'.$row['provider'].'</td>
                                                <td>'.$row['plan_type'].'</td>
                                                <td>'.$row['data_amount'].'</td>
                                                <td>RM '.$row['price'].'</td>
                                                <td>'.ucfirst($row['status']).'</td>
                                                <td>'.date('d-m-Y h:i A', strtotime($row['order_date'])).'</td>
                                            </tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="7" class="text-center">No simcard orders found</td></tr>';
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include "footer.php"; ?>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>
</html>