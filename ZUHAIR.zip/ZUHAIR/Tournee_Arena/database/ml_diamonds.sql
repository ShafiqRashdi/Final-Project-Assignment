-- Table structure for table `ml_diamonds`
CREATE TABLE `ml_diamonds` (
  `diamond_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `game_id` varchar(50) NOT NULL,
  `server_id` varchar(50) NOT NULL,
  `diamond_amount` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`diamond_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;