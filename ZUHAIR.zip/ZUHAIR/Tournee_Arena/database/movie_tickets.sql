-- Table structure for movie_tickets

CREATE TABLE `movie_tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `movie_name` varchar(255) NOT NULL,
  `cinema` varchar(100) NOT NULL,
  `show_date` date NOT NULL,
  `show_time` varchar(50) NOT NULL,
  `num_tickets` int(11) NOT NULL,
  `seat_numbers` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;